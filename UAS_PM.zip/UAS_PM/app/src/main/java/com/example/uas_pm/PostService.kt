package com.example.uas_pm

import io.reactivex.rxjava3.core.Single
import retrofit2.http.*

interface PostService {
    @GET("posts")
    fun getPost():Single<ResponsePost>

    @POST("posts")
    fun addPost(@Body bodyPost: BodyPost):Single<ResponseAddPost>

    @POST("posts")
    fun putPost(@Body bodyPost: BodyPost):Single<ResponseAddPost>

    @PATCH("posts")
    fun patchPost(@Field("title") title:String):Single<ResponseAddPost>

    @DELETE("posts/{id}")
    fun deletePost(@Path("id") id:Int):Single<ResponseAddPost>
}